<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class countries_data extends Model
{
    //
}
