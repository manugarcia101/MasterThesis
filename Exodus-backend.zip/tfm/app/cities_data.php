<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cities_data extends Model
{
    //
}
