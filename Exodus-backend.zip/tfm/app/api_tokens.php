<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class api_tokens extends Model
{
    //
}
