export const environment = {
  production: true,
  mapBoxToken: 'pk.eyJ1IjoibWFudWdhcmNpYTEwMXVvYyIsImEiOiJjazh4YzdiaGkwaTIwM21xb3V0NHc5NXdnIn0.3PtKpJvPkT9i8p26CM9pBw'
};
